package metier.piece;

import ihm.Case;

import java.util.ArrayList;

/**
 * Created by mj150192 on 13/06/16.
 */
public class Vide extends Piece
{
    @Override
    public ArrayList<int[]> caseEchec(int i, int j, Case[][] tPlateau)
    {
        return null;
    }

    @Override
    public ArrayList<int[]> caseValide(int i, int j, Case[][] tPlateau)
    {
        return null;
    }
}